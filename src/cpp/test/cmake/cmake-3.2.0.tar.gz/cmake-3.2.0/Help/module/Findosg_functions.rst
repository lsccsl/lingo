.. cmake-module:: ../../Modules/Findosg_functions.cmake
