.. cmake-module:: ../../Modules/FindQuickTime.cmake
