.. cmake-module:: ../../Modules/ExternalData.cmake
