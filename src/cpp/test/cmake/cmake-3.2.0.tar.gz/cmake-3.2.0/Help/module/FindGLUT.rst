.. cmake-module:: ../../Modules/FindGLUT.cmake
