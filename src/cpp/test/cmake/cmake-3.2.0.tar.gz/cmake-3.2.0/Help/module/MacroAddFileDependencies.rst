.. cmake-module:: ../../Modules/MacroAddFileDependencies.cmake
